You need the following libraries:

numpy
matplotlib
operator
collections
random
math
pylab

Run the main.py from terminal. 

The KNN.py is imported to main.py, and all knn-results are called there.

To switch between normalized and not-normalized train and test set, specify in main.py in lines 248 and 259.

To switch between different lists of K, specify in line 247 in main.py